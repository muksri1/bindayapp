# README additions

Add these to your existing README.md (or replace the deployment section):

---

## Deployment note — Pi 3A+ / 512MB boards

The originally documented systemd approach needed rework for low-memory boards running Trixie/labwc. The working architecture is:

- **Servers** (`proxy.py` + static server) → system service `binday.service`
- **Chromium kiosk** → systemd **user** service anchored to `default.target`, with a triple wait (wayland socket → server up → 15s settle) and `--disable-gpu`

Full details, the final service files, and every failure mode encountered: **[docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)**

## Screenshots

![Kiosk running on 7" display](docs/images/kiosk-running-setup-screen.jpg)
