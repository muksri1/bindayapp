"""
proxy.py — Local CORS proxy for Blacktown Council waste services API.
Run this on your Raspberry Pi alongside the static app.

Usage:
    pip install flask requests
    python3 proxy.py

Listens on http://localhost:3001
"""

from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

COUNCIL_API = "https://www.blacktown.nsw.gov.au/api/v1/myblacktown/waste-services"


@app.after_request
def add_cors(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return response


@app.route("/waste")
def waste():
    address = request.args.get("address", "").strip()
    housenum = request.args.get("housenum", "").strip()

    if not address:
        return jsonify({"error": "address parameter required"}), 400

    try:
        params = {"address": address}
        if housenum:
            params["housenum"] = housenum

        resp = requests.get(COUNCIL_API, params=params, timeout=10)
        resp.raise_for_status()
        return jsonify(resp.json())

    except requests.exceptions.ConnectionError:
        return jsonify({"error": "Could not reach Blacktown Council API"}), 502
    except requests.exceptions.Timeout:
        return jsonify({"error": "Council API timed out"}), 504
    except requests.exceptions.HTTPError as e:
        return jsonify({"error": f"Council API returned {e.response.status_code}"}), 502


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    print("Bin day proxy running on http://localhost:3001")
    app.run(host="127.0.0.1", port=3001)
