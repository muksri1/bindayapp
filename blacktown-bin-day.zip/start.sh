#!/bin/bash
# start.sh — Launch the bin day app on Raspberry Pi
# Starts the CORS proxy, serves static files, and opens Chromium in kiosk mode.

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PORT_APP=8080
PORT_PROXY=3001

echo "Starting CORS proxy on :$PORT_PROXY..."
python3 "$SCRIPT_DIR/proxy.py" &
PROXY_PID=$!

echo "Serving app on :$PORT_APP..."
python3 -m http.server $PORT_APP --directory "$SCRIPT_DIR/src" &
APP_PID=$!

sleep 2

echo "Opening Chromium in kiosk mode..."
chromium-browser \
  --kiosk \
  --noerrdialogs \
  --disable-infobars \
  --disable-session-crashed-bubble \
  --no-first-run \
  --disable-translate \
  "http://localhost:$PORT_APP" &

trap "kill $PROXY_PID $APP_PID 2>/dev/null" EXIT
wait
