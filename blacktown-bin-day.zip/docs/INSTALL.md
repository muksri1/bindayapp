# Installation guide — Raspberry Pi Zero 2W

Step-by-step deployment of the bin day display on a Pi Zero 2W with an HDMI display.

## 1. Flash the SD card

1. Download [Raspberry Pi Imager](https://www.raspberrypi.com/software/)
2. OS: **Raspberry Pi OS (Legacy, 32-bit) with Desktop** — the Zero 2W has 512MB RAM; Desktop is required for Chromium kiosk mode
3. Click the gear icon (Edit Settings) before writing:
   - Hostname: `binday`
   - Enable SSH (password authentication)
   - Set username and password
   - Configure Wi-Fi (SSID, password, country `AU`)
   - Timezone: `Australia/Sydney`
4. Write the image and insert the card into the Pi

## 2. First boot

1. Connect the display (mini-HDMI adapter) and power (micro-USB port labelled PWR — the outer port)
2. Allow ~2 minutes for first boot
3. SSH in from another machine:

```bash
ssh pi@binday.local
```

## 3. Install the app

```bash
sudo apt update && sudo apt install -y python3-flask python3-requests git
git clone https://github.com/<your-username>/blacktown-bin-day.git
cd blacktown-bin-day
chmod +x start.sh
```

Smoke test:

```bash
./start.sh
```

The setup screen appears on the display. Enter your address once (persists in localStorage). Ctrl+C to stop.

## 4. Autostart on boot

Option A — systemd:

```bash
sudo cp binday.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now binday
```

Option B — LXDE autostart (more reliable for GUI apps on Pi OS):

```bash
mkdir -p ~/.config/autostart
cat > ~/.config/autostart/binday.desktop << 'EOF'
[Desktop Entry]
Type=Application
Name=BinDay
Exec=/bin/bash /home/pi/blacktown-bin-day/start.sh
EOF
```

Use one method only. If systemd shows a blank screen (Chromium starting before the desktop session), switch to Option B.

## 5. Kiosk hardening

```bash
# Disable screen blanking
sudo raspi-config nonint do_blanking 1

# Hide idle mouse cursor
sudo apt install -y unclutter
echo "@unclutter -idle 1" >> ~/.config/lxsession/LXDE-pi/autostart

# Optional: nightly reboot at 3am
(crontab -l 2>/dev/null; echo "0 3 * * * /sbin/shutdown -r now") | sudo crontab -
```

## 6. Mount and verify

1. Attach the Pi to the back of the display (velcro / 3M tape), mount near the garage or front door
2. `sudo reboot` — confirm it boots straight into the kiosk display
3. Verify Monday shows the correct bins and Tuesday morning shows the collection-day state

## Troubleshooting

| Symptom | Fix |
|---|---|
| Blank screen after boot | `systemctl status binday`; switch to LXDE autostart (Option B) |
| "No signal" on display | Add `hdmi_force_hotplug=1` to `/boot/config.txt` |
| Wrong bins shown | Proxy unreachable — app fell back to local calculation. Check `curl localhost:3001/health`. Verify `YELLOW_REF` in `src/index.html` matches your cycle |
| Wi-Fi drops overnight | Disable Wi-Fi power management: `sudo iwconfig wlan0 power off` (persist via `/etc/rc.local`) |
